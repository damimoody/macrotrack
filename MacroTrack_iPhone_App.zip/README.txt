# MacroTrack PWA

A no-App-Store progressive web app for tracking calories, protein, carbohydrates, and fat.

## Included
- Daily food diary (breakfast, lunch, dinner, snacks)
- Editable daily goals (starts at 2,000 kcal / 150g protein / 200g carbs / 67g fat)
- Daily history, saved favorite foods, export/import backup
- Offline app shell after first load
- iPhone home-screen icon and standalone display

## Important
Food entries are saved in browser storage on the device/browser where they are entered. They do not automatically sync between devices. Export backups regularly. This starter version uses manual nutrition entry; it does not yet include a verified food database or barcode lookup.

## Put it online for iPhone installation
The app must be hosted on an HTTPS website for service workers and reliable iPhone installation. One straightforward free option is GitHub Pages:

1. Sign in to GitHub and create a new public repository named `macrotrack`.
2. Upload all five files in this folder (`index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`) to the repository's root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select **main** and **/(root)**, then Save.
5. Wait for GitHub Pages to publish the site. Its address will look like `https://YOUR-USERNAME.github.io/macrotrack/`.
6. On your iPhone, open that address in **Safari**.
7. Tap **Share** → **Add to Home Screen** → **Add**.
8. Open MacroTrack from the new Home Screen icon.

Keep the repository public if using the free GitHub Pages plan. Do not put personal or sensitive information in the repository. The food diary itself is stored locally in the browser, not in GitHub.

## Updating
When a newer version is ready, replace the files in the repository. The service worker cache updates on the next visit/reload.
